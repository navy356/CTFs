print("a")
